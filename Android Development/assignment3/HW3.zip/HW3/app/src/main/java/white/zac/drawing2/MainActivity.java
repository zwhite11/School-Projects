package white.zac.drawing2;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private Drawable diamondDrawable;
    private Drawable rhombusDrawable;
    private Drawable squareDrawable;
    private Drawable circleDrawable;

    private float shapeSize;

    CustomView customView;
    private volatile ArrayList<Thing> things = new ArrayList<>();

    ArrayList<Integer> matches = new ArrayList<>();

    Paint paint;
    float strokeWidth;
    ColorStateList strokeColor;

    boolean firstDraw;

    int currOrientation;

    private volatile Thing tappedThing = null;
    private volatile boolean blink = false;
    private volatile boolean highlight = false;

    private Object lock = new Object();

    float oldX = -1;
    float oldY = -1;

    private volatile Thing  selectedThing = null;
    private volatile Thing toSwap = null;
    private volatile Rect selectedBounds;

    private int score;
    private volatile String scoreText = "Your Score: " + score;
    private boolean onBoard;
    private boolean shuffled;
    private boolean paused;

    private volatile ArrayList<Integer> currentMatches;
    private volatile ArrayList<Rect> bounds;

    private volatile int matchIndex;
    private volatile int selectedIndex;
    private volatile int toSwapIndex;

    private Runnable blinker = new Runnable() {
        @Override
        public void run() {
            try {
                synchronized (lock){
                    blink = true;
                    customView.postInvalidate();
                }
                Thread.sleep(250);
                synchronized (lock){
                    blink = false;
                    customView.postInvalidate();
                }

                Thread.sleep(250);
                synchronized (lock){
                    blink = true;
                    customView.postInvalidate();
                }
                Thread.sleep(250);
                synchronized (lock){
                    blink = false;
                    customView.postInvalidate();
                }

                tappedThing = null;
            } catch (InterruptedException e) {
                blink = false;
            }

        }
    };

    private Runnable highlighter = new Runnable() {
        @Override
        public void run() {
            System.out.println("HIGHLIGHTER STARTED");
            while(matchIndex >= 0){
                synchronized (lock){
                    System.out.println("IN THE WHILE LOOP!!");
                    currentMatches = checkForMatches(things.get(matchIndex), matchIndex);
                    //match in multiple directions
                    ArrayList<Integer> moreMatches = new ArrayList<>();
                    //find matches in all directions
                    for (int i : currentMatches) {
                        moreMatches.addAll(checkForMatches(things.get(i), i));
                    }

                    currentMatches.addAll(moreMatches);
                    //only add to current matches if not already there
                    Set<Integer> uniqueMatches = new HashSet<>();
                    uniqueMatches.addAll(currentMatches);
                    currentMatches.clear();
                    currentMatches.addAll(uniqueMatches);
                }


                try {
                    synchronized (lock){
                        highlight = true;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = false;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = true;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = false;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = true;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = false;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = true;
                        customView.postInvalidate();
                    }
                    Thread.sleep(300);
                    synchronized (lock){
                        highlight = false;
                        customView.postInvalidate();
                    }

                } catch (InterruptedException e) {
                    highlight = false;
                }
                synchronized (lock) {
                    System.out.println("CLEAR MATCHES??" + (currentMatches != null));
                    System.out.println("matches size: " + currentMatches.size());
                    for (int i : currentMatches) {
                        System.out.println("match at: " + i);
                    }

                    if (currentMatches != null) {
                        score += currentMatches.size();
                        clearMatches();
                        shiftDown();
                        fillEmpties();
                    }
                }
                    customView.postInvalidate();
                    System.out.println("highlighter: " + matchesOnBoard() + " " + System.currentTimeMillis());
                    selectedThing = null;
                    toSwap = null;
                    matchIndex = matchesOnBoard();

            }
            for(int i =0; i < things.size(); i++){
                System.out.println(i + " " + things.get(i).getType());
            }
            System.out.println("HIGHLIGHTER DONE!!!!!");
        }
    };



    private Runnable matcher = new Runnable() {
        @Override
        public void run() {
            synchronized (lock){
                System.out.println("MATCHER STARTED");
                //check to see if it is a valid move
                selectedIndex = things.indexOf(selectedThing);
                toSwapIndex = things.indexOf(toSwap);

                //is a valid swap
                if (isValidSwap(selectedIndex, toSwapIndex)) {
                    //make swap
                    //new things
                    Thing thing1 = new Thing(selectedThing.getType(), toSwap.getBounds());
                    Thing thing2 = new Thing(toSwap.getType(), selectedBounds);

                    things.set(selectedIndex, thing2);
                    things.set(toSwapIndex, thing1);

                    // handle matches
                    matchIndex = matchesOnBoard();
                    System.out.println("matcher:  " + matchIndex + " " + System.currentTimeMillis());
                    //no matches
                    if (matchIndex < 0) {
                        //return shapes to original spots.
                        things.set(selectedIndex, selectedThing);
                        things.set(toSwapIndex, toSwap);

                        selectedThing.setBounds(selectedBounds);
                    }
                }
                else{
                    selectedThing.setBounds(selectedBounds);
                }
            }
            customView.postInvalidate();
            System.out.println("MATCHER DONE!!!!!");

            new Thread(highlighter).start();
        }
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        strokeWidth  = getResources().getDimension(R.dimen.strokeWidth);
        strokeColor  = getResources().getColorStateList(R.color.stroke);
        squareDrawable = getResources().getDrawable(R.drawable.square);
        circleDrawable = getResources().getDrawable(R.drawable.circle);
        rhombusDrawable = createRhombus((int) strokeWidth, Color.YELLOW, strokeColor);
        diamondDrawable = createDiamond((int) strokeWidth, Color.CYAN, strokeColor);
        paint = new Paint();

        if (savedInstanceState != null){
            things = savedInstanceState.getParcelableArrayList("things");
            score = savedInstanceState.getInt("score");
        }
        else{ //no saved instance
            makeThings();
            firstDraw = true;
            if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
                currOrientation = 2;
            }
            else{
                currOrientation = 1;
            }

        }

        LinearLayout mainLayout = (LinearLayout) findViewById(R.id.mainLayout);
        customView = new CustomView(this);


        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        customView.setLayoutParams(layoutParams);


        assert mainLayout != null;
        mainLayout.addView(customView);

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("things", things);
        outState.putInt("score", score);
    }

    private ShapeDrawable createDiamond(int strokeWidth, int triangleFillColor, ColorStateList strokeColor) {

        final Diamond diamond = new Diamond(strokeWidth, triangleFillColor, strokeColor);

        ShapeDrawable shapeDrawable = new ShapeDrawable(diamond) {
            @Override
            protected boolean onStateChange(int[] stateSet) {
                diamond.setState(stateSet);
                return super.onStateChange(stateSet);
            }

            @Override
            public boolean isStateful() {
                return true;
            }

        };

        shapeDrawable.setIntrinsicHeight((int) shapeSize-10);
        shapeDrawable.setIntrinsicWidth((int) shapeSize-10);

        return shapeDrawable;
    }

    private ShapeDrawable createRhombus(int strokeWidth, int triangleFillColor, ColorStateList strokeColor) {

        final Rhombus rhombus = new Rhombus(strokeWidth, triangleFillColor, strokeColor);

        ShapeDrawable shapeDrawable = new ShapeDrawable(rhombus) {
            @Override
            protected boolean onStateChange(int[] stateSet) {
                rhombus.setState(stateSet);
                return super.onStateChange(stateSet);
            }

            @Override
            public boolean isStateful() {
                return true;
            }
        };

        shapeDrawable.setIntrinsicHeight((int) shapeSize-10);
        shapeDrawable.setIntrinsicWidth((int) shapeSize-10);

        return shapeDrawable;
    }

    //creates random shapes
    public Thing randomShape(){
        Thing thing = null;
        Random random = new Random();
        int rand = random.nextInt(4); // returns 0‐3 to choose which shape
        switch(rand){
            case 0:
                thing =  new Thing(Thing.Type.Square);
                break;
            case 1:
                thing =  new Thing(Thing.Type.Diamond);
                break;
            case 2:
                thing = new Thing(Thing.Type.Rhombus);
                break;
            case 3:
                thing = new Thing(Thing.Type.Circle);
                break;

        }

        return thing;

    }

    //makes the arraylist of Things
    private void makeThings() {
        // 64 shapes
        for(int i = 0 ; i < 64; i++){
            things.add(randomShape());
            while(matchesAbove(i) || matchesLeft(i)){
                Thing newThing = randomShape();
                things.set(i, newThing);
            }

        }
    }

    //clears the list of things and recreates it
    private void shuffleShapes() {
        things.clear();
        makeThings();
        score -= 10;
        shuffled = true;
    }

    // methods for checking the 4 directions for matches
    public void checkLeft(Thing thing, int a, ArrayList checked) {
        //if the shape is not on the left edge
        if(a%8 != 0 ){
            // if thing and thing left aren't null
            if(thing !=null && things.get(a-1) !=null){
                if (thing.getType() == things.get(a - 1).getType()) {
                    checked.add(a-1);
                    checkLeft(thing, a-1, checked);
                }
            }

        }

    }
    public void checkUp(Thing thing, int a, ArrayList checked) {
        //if the shape is not on the top edge
        if(a > 7 ){
            if(thing != null && things.get(a-8) != null){
                if (thing.getType() == things.get(a - 8).getType()) {
                    checked.add(a-8);
                    checkUp(thing, a-8, checked);
                }
            }

        }
    }
    public void checkRight(Thing thing, int a, ArrayList checked) {
        //if the shape is not on the right edge
        if(a%8 != 7 ){
            if(thing != null && things.get(a+1) != null){
                if (thing.getType() == things.get(a + 1).getType()) {
                    checked.add(a+1);
                    checkRight(thing, a+1, checked);
                }
            }

        }
    }
    public void checkDown(Thing thing, int a, ArrayList checked) {
        //if the shape is not on the top edge
        if(a < 56 ){
            if(thing != null && things.get(a+8) != null){
                if (thing.getType() == things.get(a + 8).getType()) {
                    checked.add(a+8);
                    checkDown(thing, a+8, checked);
                }
            }

        }
    }


    //checks for matches at a given spot. returns a list of the indices of those matches
    public ArrayList<Integer> checkForMatches(Thing thing, int a){

        ArrayList<Integer> allMatches = new ArrayList();

        ArrayList<Integer> leftMatches = new ArrayList<>();
        checkLeft(thing, a, leftMatches);

        ArrayList<Integer> upMatches = new ArrayList();
        checkUp(thing, a, upMatches);

        ArrayList<Integer> rightMatches = new ArrayList();
        checkRight(thing, a, rightMatches);

        ArrayList<Integer> downMatches = new ArrayList();
        checkDown(thing, a, downMatches);

        int horizontalMatches = leftMatches.size() + rightMatches.size() + 1;
        if (horizontalMatches >= 3) {
            allMatches.addAll(leftMatches);
            allMatches.addAll(rightMatches);
        }

        int verticalMatches = upMatches.size() + downMatches.size() + 1;
        if (verticalMatches >= 3) {
            allMatches.addAll(upMatches);
            allMatches.addAll(downMatches);
        }

        allMatches.add(a);


        return allMatches;
    }

    //checks board for matches, returns the index of the first occurrence of a match
    public int matchesOnBoard(){
        for(int i = 0; i < things.size(); i++){
            matches = checkForMatches(things.get(i), i);
            if(matches.size() > 1){
                return i;
            }
        }
        return -1;
    }

    //changes all matched shapes to nulls making them show empty on the board
    public void clearMatches(){
        for(int i: currentMatches){
            things.set(i, null);
        }
        //add matches to score
        currentMatches = null;
    }

    //fills all the nulls with random shapes
    public void fillEmpties(){
        for(int i = 0; i < things.size(); i++){
            if(things.get(i) == null){
                Thing newThing = randomShape();
                newThing.setBounds(bounds.get(i));
                things.set(i, newThing);
            }
        }
    }

    //shift shapes down when matches are removed
    public void shiftDown(){
        for(int i = 0; i < things.size(); i++){

            if(i+8 < things.size()){ //if not on the bottom row
                int index = i;
                while(things.get(index+8) == null && index > 7){
                    Thing thingAboveNull = things.get(index);

                    things.set(index+8, thingAboveNull);
                    things.set(index, null);

                    index -= 8;
                }

                if (things.get(index+8) == null && index < 8){
                    Thing thingAboveNull = things.get(index);
                    things.set(index+8, thingAboveNull);
                    things.set(index, null);

                }

            }

        }

        placeShapes();

    }


    //method for place all the shapes to the bounds of the board
     public void placeShapes() {
        for(int i = 0; i < things.size(); i++){
            Thing thing = things.get(i);
            if(thing != null){
                thing.setBounds(bounds.get(i));
            }
        }
    }



    //finds matching shapes to left of given index
    public boolean matchesLeft(int i){
        Thing toCompare = things.get(i);
        //ignore first two columns
        if(i%8 == 0 || i%8 == 1){
            return false;
        }

        //2 matches to the left
        if(toCompare.getType() == things.get(i-1).getType()){
            if(things.get(i-1).getType() == things.get(i-2).getType()){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }

    }

    //finds matching shapes to the left of given index
    public boolean matchesAbove(int i){
        Thing toCompare = things.get(i);
        //ignore top two rows
        if(i < 16){
            return false;
        }

        //2 matches above
        if(toCompare.getType() == things.get(i-8).getType()){
            if(things.get(i-8).getType() == things.get(i-16).getType()){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }

    //checks to see if the two given shapes are next to each other
    public boolean isValidSwap(int a, int b){
        int sum = Math.abs(a-b);
        if (sum == 1 || sum == 8){
            return true;
        }
        else{
            return false;
        }
    }



    private class CustomView extends View {

        Rect board = new Rect();

        //board info
        int boardLeft;
        int boardTop;
        int boardRight;
        int boardBottom;

        int screenWidth;
        int screenHeight;

        public CustomView(Context context) {
            super(context);
            setWillNotDraw(false);
        }

        private void drawGameBoard(Canvas canvas) {
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);

            screenWidth = getWidth();
            screenHeight = getHeight();

            Paint scorePaint = new Paint();
            scorePaint.setColor(Color.RED);
            scorePaint.setTextSize(75);
            scoreText = "Your Score: " + score;

            //cell size in pixels = 108 in portrait, 86 in landscape
            float div = ( Math.min(screenWidth, screenHeight) )/10;

            shapeSize = div - 5;

            int squareSideLength = ( Math.min(screenWidth, screenHeight) ) - (int) (div*2);


            //portrait
            if(screenHeight > screenWidth){
                boardLeft = (int) div;
                boardTop = (screenHeight - squareSideLength)/2;
                boardRight = (int)(getWidth()-div);
                boardBottom =  (getHeight()- boardTop);

                canvas.drawText(scoreText, boardLeft, boardTop-50, scorePaint);
            }
            //landscape
            else {
                boardLeft = (screenWidth - squareSideLength)/2;
                boardTop =  (int) div;
                boardRight = (getWidth()- boardLeft);
                boardBottom = (int)( getHeight() - div);

                canvas.drawText(scoreText, boardRight+50, boardTop +50,scorePaint);
            }

            board.set(boardLeft, boardTop, boardRight, boardBottom);


            canvas.drawRect(board, paint);

            float width8th = board.width()/8;
            float height8th = board.height()/8;

            // draw board lines
            for(int i = 1; i < 8; i++){
//       canvas.drawLine(startx, starty,stopx, stopy);

                //vertical
                canvas.drawLine( (board.left + width8th), board.top, (board.left + width8th), board.bottom, paint );
                //horizontal
                canvas.drawLine(board.left, (board.top + height8th), board.right, (board.top + height8th), paint );


                height8th += board.height()/8;
                width8th += board.width()/8;
            }

            //shapes need shuffling
            if(shuffled){
                drawShapes(canvas);
                shuffled = false;
            }

            //handles rotation change
            if( (currOrientation != getResources().getConfiguration().orientation) ||
                    firstDraw){
                drawShapes(canvas);
                //make array of bounds
                bounds = new ArrayList<>();
                for(int i = 0; i < things.size(); i++){
                    bounds.add(things.get(i).getBounds());
                }
                firstDraw = false;
                currOrientation = getResources().getConfiguration().orientation;
            }

        }

        //drawing shapes
        public void drawShapes(Canvas canvas){
            screenWidth = getWidth();
            screenHeight = getHeight();
            float div = ( Math.min(screenWidth, screenHeight) )/10;
            Drawable drawableToUse = null;
            //each row in board
            for(int i = 0; i < 8; i++){
                //in each row
                for(int j = 0; j < 8; j++){
                    Thing thing = things.get(j+(i*8));
                    if(thing != null){
                        switch(thing.getType()) {
                            case Square:
                                drawableToUse = squareDrawable;
                                break;
                            case Circle:
                                drawableToUse = circleDrawable;
                                break;
                            case Diamond:
                                drawableToUse = diamondDrawable;
                                break;
                            case Rhombus:
                                drawableToUse = rhombusDrawable;
                                break;
                        }

                        Rect newBounds = new Rect((int) (boardLeft + (div*j)) + 10,
                                (int) (boardTop + (div*i)) + 10,
                                (int) ( boardLeft + ( div*(j+1) ) )-10,
                                (int) (boardTop + (div*(i+1)) - 10));
                        drawableToUse.setBounds(newBounds);
                        things.get(j+(i*8)).setBounds(newBounds);
                        drawableToUse.draw(canvas);
                    }

                }

            }

        }


        private Thing findThingAt(int x, int y) {
            for(int i = things.size()-1; i>=0; i--) {
                Thing thing = things.get(i);
                if (thing.getBounds().contains(x, y)) {
                    return thing;
                }
            }
            return null;
        }


        private Rect thingBounds(int x, int y, int size) {
            int halfSize = size / 2;
            return new Rect(x - halfSize, y - halfSize, x + halfSize, y + halfSize);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {

            switch(event.getAction()) {
                case MotionEvent.ACTION_DOWN:

                    selectedThing = findThingAt((int) event.getX(), (int) event.getY());
                    System.out.println("selected - " + selectedThing);
                    if(selectedThing != null){
                        onBoard = true;
                        tappedThing = selectedThing;
                        selectedBounds = selectedThing.getBounds();
//                        new Thread(blinker).start();
                    }
                    else{
                        if(!board.contains((int) event.getX(), (int) event.getY())){ // touch not on board
                            onBoard = false;
                        }
                    }

                    oldX = event.getX();
                    oldY = event.getY();
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (selectedThing != null) {
                        selectedThing.setBounds(thingBounds((int)event.getX(), (int)event.getY(), (int)shapeSize-10));
                    }

                    invalidate();
                    return true;

                case MotionEvent.ACTION_UP:
                    if(paused){
                        paused = false;
                    }
                    else{
                        float touch_slop = getResources().getDimension(R.dimen.touch_slop);
                        if(selectedThing == null) {
                            //thing is null and moved far enough
                            if (Math.abs(oldX - event.getX()) >= touch_slop || Math.abs(oldY - event.getY()) >= touch_slop) {
                                if (!board.contains((int) event.getX(), (int) event.getY())) { // touch not on board
                                    shuffleShapes();
                                }
                            } else {
                                paused = true;
                            }
                        }

                        //a shape was selected
                        else {
                            //shape moved far enough to register
                            if (Math.abs(oldX - event.getX()) >= touch_slop || Math.abs(oldY - event.getY()) >= touch_slop) {
                                toSwap = null;
                                //if selected a shape, check to see if it's a valid move
                                //find shape at lifted location
                                for(Thing thing: things){
                                    //ignore the selected thing
                                    if(thing != selectedThing){
                                        // if the thing contains the lifted location
                                        if( thing.getBounds().contains((int) event.getX(), (int) event.getY())){
                                            toSwap = thing;
                                        }
                                    }
                                }

                                //lifted location is not a shape
                                if(toSwap == null){
                                    selectedThing.setBounds(selectedBounds);
                                }
                                //there is a shape to swap
                                else {
                                    new Thread(matcher).start();
                                }
                            }
                            else {
                                selectedThing.setBounds(selectedBounds);
                            }

                        }

                    }

                    invalidate();
                    return true;
            }
            return super.onTouchEvent(event);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            synchronized (lock){
                if(!paused){
                    drawGameBoard(canvas);

                    Drawable drawableToUse = null;
                    //each row in board
                    for(int i = 0; i < 8; i++){
                        //in each row
                        for(int j = 0; j < 8; j++){
                            int index = j+(i*8);
                            Thing thing = things.get(index);
                            if(thing != null){
                                switch(thing.getType()) {
                                    case Square:
                                        drawableToUse = squareDrawable;
                                        break;
                                    case Circle:
                                        drawableToUse = circleDrawable;
                                        break;
                                    case Diamond:
                                        drawableToUse = diamondDrawable;
                                        break;
                                    case Rhombus:
                                        drawableToUse = rhombusDrawable;
                                        break;
                                }

                                if(currentMatches != null && currentMatches.contains(index) && highlight){
                                    drawableToUse.setState(selectedState);
                                } else {
                                    drawableToUse.setState(unselectedState);
                                }

//                                if (thing == selectedThing || (blink && tappedThing != null && thing.getType() == tappedThing.getType())) {
//                                    drawableToUse.setState(selectedState);
//                                } else {
//                                    drawableToUse.setState(unselectedState);
//                                }

                                drawableToUse.setBounds(thing.getBounds());
                                drawableToUse.draw(canvas);


                            }

                        }

                    }

                }
                else{
                    Paint pausePaint = new Paint();
                    pausePaint.setColor(Color.RED);
                    pausePaint.setTextSize(75);
                    int x = (int) (canvas.getWidth() - pausePaint.measureText("GAME PAUSED"))/2;

                    canvas.drawText("GAME PAUSED", x, getHeight()/2, pausePaint);
                }
            }


        }

    }

    private static final int[] selectedState = {android.R.attr.state_selected};
    private static final int[] unselectedState = {};

}
