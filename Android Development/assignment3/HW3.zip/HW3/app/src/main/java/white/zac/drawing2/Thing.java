package white.zac.drawing2;

import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;


public class Thing implements Parcelable {


	public Thing() {
	}

	public enum Type {
		Square, Circle, Diamond, Rhombus;
	}
	private Type type;
	private Rect bounds;


	public Thing(Type type) {
        this.type = type;
        this.bounds = null;
	}

	public Thing(Type type, Rect bounds){
		this.type = type;
		this.bounds = bounds;
	}


	protected Thing(Parcel in) {
		type = Type.valueOf(in.readString());
		bounds.readFromParcel(in);
	}

	public static final Creator<Thing> CREATOR = new Creator<Thing>() {
		@Override
		public Thing createFromParcel(Parcel in) {
			return new Thing(in);
		}

		@Override
		public Thing[] newArray(int size) {
			return new Thing[size];
		}
	};

	public void setBounds(Rect bounds) {
		this.bounds = bounds;
	}

	public Type getType() {
		return type;
	}
	public  Rect getBounds(){ return bounds;}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.type.name());
		bounds.writeToParcel(dest, flags);
	}
}
